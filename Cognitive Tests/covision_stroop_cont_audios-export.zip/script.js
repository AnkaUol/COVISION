// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.PostMessage",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "covision_stroop_cont_audios",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.html.Page",
      "items": [
        {
          "type": "text"
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "right",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {

explanationFinished = false; 

thisWord = "blah"
}
      },
      "title": "Predefine_Variable",
      "timeout": "0"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "html",
          "content": "\u003Chead\u003E\r\n    \u003Cmeta charset=\"UTF-8\"\u003E\r\n    \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\r\n    \r\n    \u003Cstyle\u003E\r\n        body {\r\n            display: flex;\r\n            flex-direction: column;\r\n            align-items: center;\r\n            justify-content: center;\r\n            min-height: 100vh;\r\n            margin: 0;\r\n            font-family: Arial, sans-serif;\r\n        }\r\n\r\n        .instruction-text {\r\n            text-align: center;\r\n            font-size: 24px;\r\n            \u002F\u002Fmax-width: 90%;\r\n        }\r\n        .finish-button {\r\n            position: absolute;\r\n            bottom: 20px;\r\n            right: 20px;\r\n            padding: 10px 20px;\r\n            background-color: #e0e0e0;\r\n            border: none;\r\n            border-radius: 8px;\r\n            font-size: 18px;\r\n            cursor: pointer;\r\n        }\r\n\r\n    \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody style=\"background-color: #ffffff; width: 100%; height: 100vh; margin: 0; padding: 0;\"\u003E\r\n\r\n\u003Cdiv style=\" width: 90%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n        \u003Cdiv class=\"instruction-text\", style = \"text-align: center;\"\u003EBitte sagen Sie, \u003Cbr\u003EIN WELCHER FARBE\u003Cbr\u003E die\r\nWorte geschrieben sind. \u003Cbr\u003E\u003Cbr\u003E\r\nLesen Sie NICHT die Worte vor. \u003Cbr\u003E\u003Cbr\u003E\r\nVersuchen Sie, so schnell wie möglich zu sein. \u003Cbr\u003E\r\n    \u003C\u002Fdiv\u003E\r\n        \u003Cbutton class=\"ready-button\" id=\"finish\" style=\"color: black\"\u003EBereit\u003C\u002Fbutton\u003E\r\n    \u003C\u002Fdiv\u003E\r\n\r\n\r\n\u003C\u002Fbody\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "instruction",
      "timeout": "30000"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "html",
          "content": "\u003Chead\u003E\r\n  \u003Ctitle\u003ELadebalken\u003C\u002Ftitle\u003E\r\n  \u003Cstyle\u003E\r\n    body {\r\n      position: absolute;\r\n      top: 50%;\r\n      left: 50%;\r\n      transform: translate(-50%, -50%);\r\n      text-align: center;\r\n    }\r\n    #bild {\r\n      width: 500px;\r\n      height: 300px;\r\n      border: 1px solid #ccc;\r\n      margin: 0 auto;\r\n    }\r\n    #text {\r\n      margin-bottom: 20px;\r\n    }\r\n    #ladebalken {\r\n      width: 90vw;\r\n      height: 20px;\r\n      border: 1px solid #ccc;\r\n      background-color: #eee;\r\n      margin: 0 auto;\r\n      margin-top: 20px;\r\n    }\r\n    #ladebalken .fortschritt {\r\n      background-color: #666;\r\n      height: 20px;\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n  \u003Cdiv style = \"width: 100%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n    \u003Ch1 id=\"text\"\"\u003EAudioaufnahme wird gestartet...\u003C\u002Fh1\u003E\r\n    \u003Cimg src=${ this.files[\"mikrophon.png\"] } alt=\"audio_aufnahme\" height=\"200\" style=\"margin: 0 auto; display: block;\"\u003E\r\n    \u003Cdiv id=\"ladebalken\"\u003E\r\n      \u003Cdiv class=\"fortschritt\" style=\"width: 0%\"\u003E\u003C\u002Fdiv\u003E\r\n    \u003C\u002Fdiv\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fbody\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {
        "mikrophon.png": "embedded\u002F16cbb94e16b7a85dd038131656be0825f486fb9b5bc9c797b6fd81e12c4cf225.png"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "run": function anonymous(
) {
var ladebalken = document.getElementById("ladebalken");
var fortschritt = document.querySelector(".fortschritt");
var startzeit = new Date().getTime();
var endzeit = startzeit + 3000; // 3 Sekunden (1 Sekunde Wartezeit + 2 Sekunden Ladebalken)

function aktualisiereLadebalken() {
  var aktuelleZeit = new Date().getTime();
  var wartezeit = startzeit + 1000; // 1 Sekunde Wartezeit
  if (aktuelleZeit < wartezeit) {
    setTimeout(aktualisiereLadebalken, 16); // 16ms = 60fps
  } else {
    var fortschrittProzent = ((aktuelleZeit - wartezeit) / (endzeit - wartezeit)) * 100;
    fortschritt.style.width = fortschrittProzent + "%";
    if (aktuelleZeit < endzeit) {
      setTimeout(aktualisiereLadebalken, 16); // 16ms = 60fps
    } else {
      fortschritt.style.width = "100%";
    }
  }
}

aktualisiereLadebalken();
}
      },
      "title": "Load audio",
      "timeout": "3000"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "html",
          "content": "\u003Chead\u003E\r\n  \u003Ctitle\u003ECountdown\u003C\u002Ftitle\u003E\r\n  \u003Cstyle\u003E\r\n    body {\r\n      font-family: Arial, sans-serif;\r\n      text-align: center;\r\n    }\r\n    #countdown {\r\n      font-size: 96px;\r\n      font-weight: bold;\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n  \u003Cdiv style=\"width: 90%; margin: 0; position: absolute; top: 10%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n  \u003Cimg src=${ this.files[\"mikrophon.png\"] } alt=\"audio_aufnahme\" height = 50\u003E\r\n\u003C\u002Fdiv\u003E\r\n    \u003Cdiv style = \"width: 100%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n      \u003Ch1\u003EDer Test beginnt in\u003C\u002Fh1\u003E\r\n      \u003Cdiv id=\"countdown\"\u003E3\u003C\u002Fdiv\u003E\r\n      \u003C\u002Fdiv\u003E\r\n \r\n\u003C\u002Fbody\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {
        "mikrophon.png": "embedded\u002F16cbb94e16b7a85dd038131656be0825f486fb9b5bc9c797b6fd81e12c4cf225.png"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "run": function anonymous(
) {

let countdown = 2;
let interval = setInterval(() => {
  document.getElementById("countdown").innerHTML = countdown;
  countdown--;
  if (countdown < 0) {
    clearInterval(interval);
    document.getElementById("countdown").innerHTML = "0";
  }
}, 1000);

}
      },
      "title": "Countdown",
      "timeout": "3000"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "html",
          "content": "\u003Chead\u003E\r\n    \u003Cmeta charset=\"UTF-8\"\u003E\r\n    \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\r\n    \r\n    \u003Cstyle\u003E\r\n        body {\r\n            display: flex;\r\n            flex-direction: column;\r\n            align-items: center;\r\n            justify-content: center;\r\n            min-height: 100vh;\r\n            margin: 0;\r\n            font-family: Arial, sans-serif;\r\n        }\r\n\r\n        .targetWord {\r\n            font-size: 64px;\r\n            text-align: center;\r\n            margin: 20px 0;\r\n        }\r\n\r\n        .area-container { \u002F* button*\u002F\r\n            width: 80%;\r\n            aspect-ratio: 4 \u002F 3;\r\n            border-radius: 8px;\r\n            background-color: white;\u002F*#e0e0e0; \u002F* Rectangle's fill color *\u002F\r\n            display: flex;\r\n            align-items: center;\r\n            justify-content: center;\r\n            text-align: center;\r\n            margin: 0 auto;\r\n            color: black; \u002F* Text color inside the rectangle *\u002F\r\n            font-size: 24px;\r\n        }\r\n    \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody style=\"background-color: #ffffff; width: 100%; height: 100vh; margin: 0; padding: 0;\"\u003E\r\n\u003Cdiv style=\"width: 90%; margin: 0; position: absolute; top: 10%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n  \u003Cimg src=${ this.files[\"mikrophon.png\"] } alt=\"audio_aufnahme\" height = 50\u003E\r\n\u003C\u002Fdiv\u003E\r\n  \r\n    \u003Cdiv id = \"stimBox\" style=\"background-color: #e0e0e0; border-radius= 8px; width: 90%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n        \u003Cdiv class=\"targetWord\"\u003E\r\n            \u003Cb\u003E\u003Cspan style=\"color: ${this.parameters.targetColor}\" id = \"targetWord\"\u003EInitialer Text\u003C\u002Fspan\u003E\u003C\u002Fb\u003E\r\n        \u003C\u002Fdiv\u003E\r\n\r\n        \u003Cdiv class=\"area-container\" id = \"continue\"\u003E\r\n            Weiter\r\n        \u003C\u002Fdiv\u003E\r\n\r\n        \u003Cdiv\u003E \u003Cbr\u003E \u003C\u002Fdiv\u003E\r\n    \u003C\u002Fdiv\u003E\r\n\u003C\u002Fbody\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {
        "mikrophon.png": "embedded\u002F16cbb94e16b7a85dd038131656be0825f486fb9b5bc9c797b6fd81e12c4cf225.png",
        "COVISION_stroop_colors_words.csv": "embedded\u002F1a375cc8b076e7857bf97616c002210330e099bb77d05094d24ddc628a2ce627.csv"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "run": function anonymous(
) {
const fixationTime = 500;

// clean up code a little
// find out why uploading takes so long

// compare directly to single trials - what is the problem?
// else can I somehow cut it into pieces or what is the thing?
// also add microphone

this.parameters.targetWords = [];
this.parameters.targetColors = [];
this.parameters.clickTimes = [];


var textIndex = 0;
var targetWord = document.getElementById("targetWord");
var contButton = document.getElementById("continue");
var stimBox = document.getElementById("stimBox");



// function to show fixationCross
function fixation() {
  targetWord.innerText = ""; // replaced "+" by "" because in SDMT it is a bit weird to have +
  targetWord.style.color = "black";
  contButton.style.color = "white";
  stimBox.style.backgroundColor = "white"
};

// function to create next stimulus
stimulus = () => {
  targetWord.innerText = colorWordList[Math.floor(Math.random() * colorWordList.length)];
  targetWord.style.color = colorColorList[Math.floor(Math.random() * colorColorList.length)];
  contButton.style.color = "black";
  stimBox.style.backgroundColor = "#e0e0e0";
    //why is this not working? It works when I execute this in the console
  this.parameters.targetWords = this.parameters.targetWords.concat(targetWord.innerText);
  this.parameters.targetColors = this.parameters.targetColors.concat(targetWord.style.color);
  this.parameters.clickTimes = this.parameters.clickTimes.concat(this.timer);
    //console.log()
  

};



// first trial
fixation()
setTimeout(function() {
  stimulus() // oder eine andere Farbe
}, fixationTime); // timer set in beginning of script

//debugger;
// each click
contButton.addEventListener("click", () => {

  fixation()

  


  // show next word afte fixationTime
  setTimeout(() => {
    stimulus() // oder eine andere Farbe

  }, fixationTime); // timer set in beginning of script

  // log data
});



},
        "before:prepare": async function anonymous(
) {


// read the file
const resp = await fetch(this.files["COVISION_stroop_colors_words.csv"]);
//const blob = await resp.blob();
//debugger
let data = await resp.text()


// this is a workaround because excel changes the line breaks to \r but the csv() function uses \n
data = data.replaceAll("\r", "\n")
data = data.split("\n")
data = data.filter((el) => el !== "")


// split var names and content by columns
const varnames = data[0].split(";")
let content = data[1].split(";")

//find the column of the wordlist variable
const colorWordListIndex = varnames.findIndex(varname => varname === "colorWordList")
// split the wordlist into its components and trim white spaces

debugger;
// this has to be defined without let to ensure that it can be accessed later
colorWordList = content[colorWordListIndex].split(",")
colorWordList= colorWordList.map(word => word.trim())
//this.parameters.targetWords = colorWordlist

//find the column of the wordlist variable
const colorColorListIndex = varnames.findIndex(varname => varname === "colorColorList")
// split the wordlist into its components and trim white spaces
// this has to be defined without let to ensure that it can be accessed later
colorColorList = content[colorColorListIndex].split(",")
colorColorList= colorColorList.map(word => word.trim())
//this.parameters.targetColors = colorColorlist



// Script for recording automatically
//
// This script must be added to the "before:prepare" stage.
//
// Note: Browsers block 'unexpected' audio recordings and playback. 
// The experiment must have some interaction before recording. 
//
// author: Tobias Busch (https://github.com/Teebusch)
// date: 2021-05-05


// ***** Configuration *******************
const codec = 'audio/ogg; codecs=opus';
//const stop_event = 'click #continue';

const timeout = 120000; // 2 min



// ***************************************



let setupRecorder = function(stream) {
  console.log("Preparing recorder...");
  
  let mediaRecorder = new MediaRecorder(stream);
  let chunks = []; 
 
  mediaRecorder.onstart = function() {
    console.log("Recording started...");
  }

  mediaRecorder.onstop = async function() {
    console.log("Recording stopped...");

    blobToAudio = (blob) => {
      return new Promise((resolve, reject) => {
        let reader = new FileReader();

        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;

        reader.readAsDataURL(blob);
      })
    }

    const blob = new Blob(chunks, { 'type' : codec });
    let audio = await blobToAudio(blob);

    c.options.datastore.set('audio', audio);
    console.log("data stored...");

    c.end(reason = "timer");
  }

  mediaRecorder.ondataavailable = function(e) {
    chunks.push(e.data);
  }

  return(mediaRecorder);
}


let c = this;

// setup recorder as early as possible before run
let stream = await navigator.mediaDevices.getUserMedia({ audio: true });
let recorder = await setupRecorder(stream);


// when run starts set up recorder and timer for stop
c.waitFor('run').then(() => {
  recorder.start();
  setTimeout(() => {
    if (recorder.state == 'recording') recorder.stop();
  }, timeout);
});




}
      },
      "title": "contStroop"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "html",
          "content": "\u003Chead\u003E\r\n  \u003Ctitle\u003ELadebalken\u003C\u002Ftitle\u003E\r\n  \u003Cstyle\u003E\r\n    body {\r\n      position: absolute;\r\n      top: 50%;\r\n      left: 50%;\r\n      transform: translate(-50%, -50%);\r\n      text-align: center;\r\n    }\r\n    #bild {\r\n      width: 500px;\r\n      height: 300px;\r\n      border: 1px solid #ccc;\r\n      margin: 0 auto;\r\n    }\r\n    #text {\r\n      margin-bottom: 20px;\r\n    }\r\n    #ladebalken {\r\n      width: 90vw;\r\n      height: 20px;\r\n      border: 1px solid #ccc;\r\n      background-color: #eee;\r\n      margin: 0 auto;\r\n      margin-top: 20px;\r\n    }\r\n    #ladebalken .fortschritt {\r\n      background-color: #666;\r\n      height: 20px;\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n  \u003Cdiv style = \"width: 100%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n    \u003Ch1 id=\"text\"\"\u003EAudioaufnahme wird beendet...\u003C\u002Fh1\u003E\r\n    \u003Cimg src=${ this.files[\"mikrophon.png\"] } alt=\"audio_aufnahme\" height=\"200\" style=\"margin: 0 auto; display: block;\"\u003E\r\n    \u003Cdiv id=\"ladebalken\"\u003E\r\n      \u003Cdiv class=\"fortschritt\" style=\"width: 0%\"\u003E\u003C\u002Fdiv\u003E\r\n    \u003C\u002Fdiv\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fbody\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {
        "mikrophon.png": "embedded\u002F16cbb94e16b7a85dd038131656be0825f486fb9b5bc9c797b6fd81e12c4cf225.png"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "run": function anonymous(
) {
var ladebalken = document.getElementById("ladebalken");
var fortschritt = document.querySelector(".fortschritt");
var startzeit = new Date().getTime();
var endzeit = startzeit + 3000; // 3 Sekunden (1 Sekunde Wartezeit + 2 Sekunden Ladebalken)

function aktualisiereLadebalken() {
  var aktuelleZeit = new Date().getTime();
  var wartezeit = startzeit + 1000; // 1 Sekunde Wartezeit
  if (aktuelleZeit < wartezeit) {
    setTimeout(aktualisiereLadebalken, 16); // 16ms = 60fps
  } else {
    var fortschrittProzent = ((aktuelleZeit - wartezeit) / (endzeit - wartezeit)) * 100;
    fortschritt.style.width = fortschrittProzent + "%";
    if (aktuelleZeit < endzeit) {
      setTimeout(aktualisiereLadebalken, 16); // 16ms = 60fps
    } else {
      fortschritt.style.width = "100%";
    }
  }
}

aktualisiereLadebalken();
}
      },
      "title": "Stop audio",
      "timeout": "3000"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": -25,
          "angle": 0,
          "width": 2,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 25,
          "top": -125,
          "angle": 0,
          "width": 428.71,
          "height": 78.11,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Bitte Warten Sie kurz.\nDie Daten werden übertragen.",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "image",
          "left": 10,
          "top": 100,
          "angle": 0,
          "width": 362.88,
          "height": 307.8,
          "stroke": null,
          "strokeWidth": 0,
          "fill": "black",
          "src": "${ this.files[\"covision_logo_short_black_blue_orange(1).png\"] }"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {
        "covision_logo_short_black_blue_orange(1).png": "embedded\u002Fc75489a57916f11757bcd1795400528b51d5f9858e64fbaefe640248c2ebd19b.png"
      },
      "responses": {
        "click": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Wait",
      "timeout": "0"
    }
  ]
})

// Let's go!
study.run()