// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.PostMessage",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "COVISION_pilot_sdmt",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.html.Page",
      "items": [
        {
          "type": "text"
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "right",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
/*
lab.extensions = {},
lab.extensions.myVariable = {};
lab.extensions.myVariable = 'Hello, World!';

lab.test = {};
lab.test = 'test';

tooth = {};
tooth = 'tooth';

*/

explanationFinished = false; 
}
      },
      "title": "Predefine_Variable",
      "timeout": "0"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "type": "text"
        },
        {
          "required": true,
          "type": "html",
          "content": "\u003Chead\u003E\r\n    \u003Cmeta charset=\"UTF-8\"\u003E\r\n    \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\r\n    \r\n    \u003Cstyle\u003E\r\n        body {\r\n            display: flex;\r\n            flex-direction: column;\r\n            align-items: center;\r\n            justify-content: center;\r\n            min-height: 100vh;\r\n            margin: 0;\r\n            font-family: Arial, sans-serif;\r\n        }\r\n\r\n        .instruction-text {\r\n            text-align: center;\r\n            font-size: 24px;\r\n            \u002F\u002Fmax-width: 90%;\r\n        }\r\n        .finish-button {\r\n            position: absolute;\r\n            bottom: 20px;\r\n            right: 20px;\r\n            padding: 10px 20px;\r\n            background-color: #e0e0e0;\r\n            border: none;\r\n            border-radius: 8px;\r\n            font-size: 18px;\r\n            cursor: pointer;\r\n        }\r\n\r\n    \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n\r\n\u003Cdiv style=\" width: 90%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n        \u003Cdiv class=\"instruction-text\", style = \"text-align: center;\"\u003EBitte wählen Sie das Symbol aus, das zu der Zahl gehört.\u003Cbr\u003E\r\n    \u003C\u002Fdiv\u003E\r\n        \u003Cbutton class=\"ready-button\" id=\"finish\" style=\"color: black\"\u003EBereit\u003C\u002Fbutton\u003E\r\n    \u003C\u002Fdiv\u003E\r\n\r\n\r\n\u003C\u002Fbody\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions",
      "timeout": "30000"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "html",
          "content": "\u003Chead\u003E\r\n  \u003Ctitle\u003ECountdown\u003C\u002Ftitle\u003E\r\n  \u003Cstyle\u003E\r\n    body {\r\n      font-family: Arial, sans-serif;\r\n      text-align: center;\r\n    }\r\n    #countdown {\r\n      font-size: 96px;\r\n      font-weight: bold;\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n    \u003Cdiv style = \"width: 100%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n      \u003Ch1\u003EDer Test beginnt in\u003C\u002Fh1\u003E\r\n      \u003Cdiv id=\"countdown\"\u003E3\u003C\u002Fdiv\u003E\r\n      \u003C\u002Fdiv\u003E\r\n \r\n\u003C\u002Fbody\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "run": function anonymous(
) {

let countdown = 2;
let interval = setInterval(() => {
  document.getElementById("countdown").innerHTML = countdown;
  countdown--;
  if (countdown < 0) {
    clearInterval(interval);
    document.getElementById("countdown").innerHTML = "0";
  }
}, 1000);

}
      },
      "title": "Countdown",
      "timeout": "3000"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "": ""
        }
      ],
      "sample": {
        "mode": "draw-shuffle",
        "n": "120"
      },
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "SymbolTrials",
      "timeout": "120000",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "SymbolSequence",
        "content": [
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 2,
                "height": 144.64,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": "128",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "FixationCross",
            "timeout": "500"
          },
          {
            "type": "lab.html.Page",
            "items": [
              {
                "required": true,
                "type": "html",
                "content": "\u003Chead\u003E\r\n   \u003Cstyle\u003E\r\n          .flex-container {\r\n      display: flex;\r\n      flex-wrap: wrap;\r\n      justify-content: space-around;\r\n      padding: 20px;\r\n      background-color:  #f5f5f5;\r\n      border-radius: 10px;\r\n      margin-bottom: 20px;\r\n    }\r\n    .flex-item {\r\n      flex: 16.66%;\r\n      border-left: 2px solid black;\r\n      font-size: 42px;\r\n      text-align: center;\r\n    }\r\n    .flex-item:first-child, .flex-item:nth-child(7) {\r\n      border-left: none;\r\n    }\r\n      .middle-container {\r\n         text-align: center;\r\n         padding: 20px;\r\n      }\r\n      .targetNum {\r\n         font-size: 64px;\r\n      }\r\n      \r\n    .flex-container-button {\r\n      display: flex;\r\n      flex-wrap: wrap;\r\n      justify-content: space-around;\r\n      padding: 0x;\r\n      border-radius: 0px;\r\n      margin-bottom: 0px;\r\n      \r\n    }\r\n\r\n      .grid-button {\r\n        flex: 31.3333%;\r\n         aspect-ratio: 1;\r\n         font-size: 64px;\r\n         background-color: #e0e0e0;\r\n         border: none;\r\n         border-radius: 8px;\r\n         cursor: pointer;\r\n         margin: 1%;\r\n         display: flex;\r\n         justify-content: center;\r\n         align-items: center;\r\n      }\r\n      .grid-button div {\r\n        font-size: 64px;\r\n      }\r\n   \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody style=\"background-color: #ffffff; width: 100%; height: 100vh; margin: 0; padding: 0;\"\u003E\r\n    \u003Cdiv class=\"flex-container\"; style = \"width: 90%; margin: 0; position: absolute; top: 25%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n    \u003Cdiv class=\"flex-item\"\u003E1\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"flex-item\"\u003E2\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"flex-item\"\u003E3\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"flex-item\"\u003E4\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"flex-item\"\u003E5\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"flex-item\"\u003E6\u003C\u002Fdiv\u003E\r\n\r\n    \u003Cdiv class=\"flex-item\"\u003E${this.parameters.symbolsShuff1[0]}\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"flex-item\"\u003E${this.parameters.symbolsShuff1[1]}\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"flex-item\"\u003E${this.parameters.symbolsShuff1[2]}\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"flex-item\"\u003E${this.parameters.symbolsShuff1[3]}\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"flex-item\"\u003E${this.parameters.symbolsShuff1[4]}\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"flex-item\"\u003E${this.parameters.symbolsShuff1[5]}\u003C\u002Fdiv\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\r\n   \u003Cdiv class=\"middle-container\"; style = \"width: 90%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n      \u003Cspan class=\"targetNum\"\u003E${this.parameters.targetNum}\u003C\u002Fspan\u003E\r\n   \u003C\u002Fdiv\u003E\r\n   \u003Cdiv class=\"flex-container-button\"; style = \"width: 90%; margin: 0; position: absolute; top: 75%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n    \u003Cdiv class=\"grid-button\" onclick=\"this.blur()\" id = \"sym1\"\u003E\u003Cdiv\u003E${this.parameters.symbolsShuff2[0]}\u003C\u002Fdiv\u003E\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"grid-button\" onclick=\"this.blur()\" id = \"sym2\"\u003E\u003Cdiv\u003E${this.parameters.symbolsShuff2[1]}\u003C\u002Fdiv\u003E\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"grid-button\" onclick=\"this.blur()\" id = \"sym3\"\u003E\u003Cdiv\u003E${this.parameters.symbolsShuff2[2]}\u003C\u002Fdiv\u003E\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"grid-button\" onclick=\"this.blur()\" id = \"sym4\"\u003E\u003Cdiv\u003E${this.parameters.symbolsShuff2[3]}\u003C\u002Fdiv\u003E\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"grid-button\" onclick=\"this.blur()\" id = \"sym5\"\u003E\u003Cdiv\u003E${this.parameters.symbolsShuff2[4]}\u003C\u002Fdiv\u003E\u003C\u002Fdiv\u003E\r\n    \u003Cdiv class=\"grid-button\" onclick=\"this.blur()\" id = \"sym6\"\u003E\u003Cdiv\u003E${this.parameters.symbolsShuff2[5]}\u003C\u002Fdiv\u003E\u003C\u002Fdiv\u003E\r\n  \u003C\u002Fdiv\u003E\r\n   \r\n\u003C\u002Fbody\u003E",
                "name": ""
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →",
            "submitButtonPosition": "hidden",
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {
              "before:prepare": function anonymous(
) {

//define symbols in original order
this.parameters.symbols = ['⊣', '⌐', ')', '+', '>', '∸']
this.parameters.numbers = [1,2,3,4,5,6]
//shuffle the order of the symbols
this.parameters.symbolsShuff1  = this.parameters.symbols.toSorted((a, b) => 0.5 - Math.random());

this.parameters.symbolsShuff2  = this.parameters.symbols.toSorted((a, b) => 0.5 - Math.random());

//pick a random number as target
this.parameters.targetNum = this.random.choice([1,2,3,4,5,6])


this.parameters.correct_sym = this.parameters.symbolsShuff1[this.parameters.targetNum - 1]

this.parameters.correct_symRes = (this.parameters.symbols.findIndex(el => el === this.parameters.correct_sym ) +1)



// #MAKE THIS MORE FLEXIBLE!!!!

const stop_event_1 = 'click #sym1';
const stop_event_2 = 'click #sym2';
const stop_event_3 = 'click #sym3';
const stop_event_4 = 'click #sym4';
const stop_event_5 = 'click #sym5';
const stop_event_6 = 'click #sym6';

let c = this;


// add event listener for ending the recording *before prepare!*
c.options.events[stop_event_1] = (e) => {
    this.parameters.sym_res = 1
    c.end(reason = stop_event_1);
  }

  c.options.events[stop_event_2] = (e) => {
    this.parameters.sym_res = 2
    c.end(reason = stop_event_2);
  }

  c.options.events[stop_event_3] = (e) => {
    this.parameters.sym_res = 3
    c.end(reason = stop_event_3);
  }

  c.options.events[stop_event_4] = (e) => {
    this.parameters.sym_res = 4
    c.end(reason = stop_event_4);
  }

  c.options.events[stop_event_5] = (e) => {
    this.parameters.sym_res = 5
    c.end(reason = stop_event_5);
  }

  c.options.events[stop_event_6] = (e) => {
    this.parameters.sym_res = 6
    c.end(reason = stop_event_6);
  }
}
            },
            "title": "SymbolTrial"
          }
        ]
      }
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": -25,
          "angle": 0,
          "width": 2,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 25,
          "top": -125,
          "angle": 0,
          "width": 428.71,
          "height": 78.11,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Bitte Warten Sie kurz.\nDie Daten werden übertragen.",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "image",
          "left": 10,
          "top": 100,
          "angle": 0,
          "width": 362.88,
          "height": 307.8,
          "stroke": null,
          "strokeWidth": 0,
          "fill": "black",
          "src": "${ this.files[\"covision_logo_short_black_blue_orange(1).png\"] }"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {
        "covision_logo_short_black_blue_orange(1).png": "embedded\u002Fc75489a57916f11757bcd1795400528b51d5f9858e64fbaefe640248c2ebd19b.png"
      },
      "responses": {
        "click": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Wait",
      "timeout": "0"
    }
  ]
})

// Let's go!
study.run()