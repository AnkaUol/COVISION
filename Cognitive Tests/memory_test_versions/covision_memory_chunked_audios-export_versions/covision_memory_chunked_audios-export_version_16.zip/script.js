// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.PostMessage",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "covision_memory_chunked_audios",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.html.Page",
      "items": [
        {
          "type": "text"
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "right",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
recallTextIndex = 0; 
recallTimeOver = 0;
}
      },
      "title": "Predefine_Variables",
      "timeout": "0"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "type": "text"
        },
        {
          "required": true,
          "type": "html",
          "content": "\u003Chead\u003E\r\n    \u003Cmeta charset=\"UTF-8\"\u003E\r\n    \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\r\n    \r\n    \u003Cstyle\u003E\r\n        body {\r\n            display: flex;\r\n            flex-direction: column;\r\n            align-items: center;\r\n            justify-content: center;\r\n            min-height: 100vh;\r\n            margin: 0;\r\n            font-family: Arial, sans-serif;\r\n        }\r\n\r\n        .instruction-text {\r\n            text-align: center;\r\n            font-size: 24px;\r\n            \u002F\u002Fmax-width: 90%;\r\n        }\r\n        .finish-button {\r\n            position: absolute;\r\n            bottom: 20px;\r\n            right: 20px;\r\n            padding: 10px 20px;\r\n            background-color: #e0e0e0;\r\n            border: none;\r\n            border-radius: 8px;\r\n            font-size: 18px;\r\n            cursor: pointer;\r\n        }\r\n\r\n    \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n\r\n\u003Cdiv style=\" width: 90%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n        \u003Cdiv class=\"instruction-text\", style = \"text-align: center;\"\u003EBitte prägen Sie sich die folgenden Worte gut ein.\u003Cbr\u003E\r\n    \u003C\u002Fdiv\u003E\r\n        \u003Cbutton class=\"ready-button\" id=\"finish\" style=\"color: black\"\u003EBereit\u003C\u002Fbutton\u003E\r\n    \u003C\u002Fdiv\u003E\r\n\r\n\r\n\u003C\u002Fbody\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Instructions",
      "timeout": "30000"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "html",
          "content": "\u003Chead\u003E\r\n  \u003Ctitle\u003ECountdown\u003C\u002Ftitle\u003E\r\n  \u003Cstyle\u003E\r\n    body {\r\n      font-family: Arial, sans-serif;\r\n      text-align: center;\r\n    }\r\n    #countdown {\r\n      font-size: 96px;\r\n      font-weight: bold;\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n    \u003Cdiv style = \"width: 100%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n      \u003Ch1\u003EDer Test beginnt in\u003C\u002Fh1\u003E\r\n      \u003Cdiv id=\"countdown\"\u003E3\u003C\u002Fdiv\u003E\r\n      \u003C\u002Fdiv\u003E\r\n \r\n\u003C\u002Fbody\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "run": function anonymous(
) {

let countdown = 2;
let interval = setInterval(() => {
  document.getElementById("countdown").innerHTML = countdown;
  countdown--;
  if (countdown < 0) {
    clearInterval(interval);
    document.getElementById("countdown").innerHTML = "0";
  }
}, 1000);

}
      },
      "title": "Countdown",
      "timeout": "3000"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "": ""
        }
      ],
      "sample": {
        "mode": "sequential",
        "n": "10"
      },
      "files": {
        "COVISION_memory_wordlists.csv": "embedded\u002Fb1fee598df13c543b40f701a60a19c90e31d94462d8dabfd963cae658c473e6b.csv"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "before:prepare": async function anonymous(
) {
// I could put all of this into a nice function

// read the file
const resp = await fetch(this.files["COVISION_memory_wordlists.csv"]);
let data = await resp.text('utf-8')



// this is a workaround because excel changes the line breaks to \r but the csv() function uses \n

debugger;
data = data.replaceAll("\r", "\n")
//data = data.replaceAll("\t", ";")
//data = data.replaceAll("\r", "\n")
data = data.split("\n")
data = data.filter((el) => el !== "")







// split var names and content by columns
const varnames = data[0].split(";")
let content = data[1].split(";")

debugger;
//find the column of the wordlist variable
const wordListIndex = varnames.findIndex(varname => varname === "memoryWordList")

// split the wordlist into its components and trim white spaces
let wordlist = content[wordListIndex].split(",")
wordlist= wordlist.map(word => word.trim())

this.parameters.targetWords = wordlist


}
      },
      "title": "MemoryPresentLoop",
      "indexParameter": "memoryLoopI",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "memoryPresentSequence",
        "content": [
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 2,
                "height": 144.64,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": "128",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "FixationCross",
            "timeout": "500"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 3540.6,
                "height": 144.64,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "${this.parameters.targetWords[this.parameters.memoryLoopI]}",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": "128",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "memoryPresentTrial",
            "timeout": "3000"
          }
        ]
      }
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "html",
          "content": "\u003Chead\u003E\r\n  \u003Ctitle\u003ELadebalken\u003C\u002Ftitle\u003E\r\n  \u003Cstyle\u003E\r\n    body {\r\n      position: absolute;\r\n      top: 50%;\r\n      left: 50%;\r\n      transform: translate(-50%, -50%);\r\n      text-align: center;\r\n    }\r\n    #bild {\r\n      width: 500px;\r\n      height: 300px;\r\n      border: 1px solid #ccc;\r\n      margin: 0 auto;\r\n    }\r\n    #text {\r\n      margin-bottom: 20px;\r\n    }\r\n    #ladebalken {\r\n      width: 90vw;\r\n      height: 20px;\r\n      border: 1px solid #ccc;\r\n      background-color: #eee;\r\n      margin: 0 auto;\r\n      margin-top: 20px;\r\n    }\r\n    #ladebalken .fortschritt {\r\n      background-color: #666;\r\n      height: 20px;\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n  \u003Cdiv style = \"width: 100%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n    \u003Ch1 id=\"text\"\"\u003EAudioaufnahme wird gestartet...\u003C\u002Fh1\u003E\r\n    \u003Cimg src=${ this.files[\"mikrophon.png\"] } alt=\"audio_aufnahme\" height=\"200\" style=\"margin: 0 auto; display: block;\"\u003E\r\n    \u003Cdiv id=\"ladebalken\"\u003E\r\n      \u003Cdiv class=\"fortschritt\" style=\"width: 0%\"\u003E\u003C\u002Fdiv\u003E\r\n    \u003C\u002Fdiv\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fbody\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {
        "mikrophon.png": "embedded\u002F16cbb94e16b7a85dd038131656be0825f486fb9b5bc9c797b6fd81e12c4cf225.png"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "run": function anonymous(
) {
var ladebalken = document.getElementById("ladebalken");
var fortschritt = document.querySelector(".fortschritt");
var startzeit = new Date().getTime();
var endzeit = startzeit + 3000; // 3 Sekunden (1 Sekunde Wartezeit + 2 Sekunden Ladebalken)

function aktualisiereLadebalken() {
  var aktuelleZeit = new Date().getTime();
  var wartezeit = startzeit + 1000; // 1 Sekunde Wartezeit
  if (aktuelleZeit < wartezeit) {
    setTimeout(aktualisiereLadebalken, 16); // 16ms = 60fps
  } else {
    var fortschrittProzent = ((aktuelleZeit - wartezeit) / (endzeit - wartezeit)) * 100;
    fortschritt.style.width = fortschrittProzent + "%";
    if (aktuelleZeit < endzeit) {
      setTimeout(aktualisiereLadebalken, 16); // 16ms = 60fps
    } else {
      fortschritt.style.width = "100%";
    }
  }
}

aktualisiereLadebalken();
}
      },
      "title": "Load Audio",
      "timeout": "3000"
    },
    {
      "type": "lab.flow.Sequence",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "MemoryRecallSequence",
      "timeout": "120000",
      "content": [
        {
          "type": "lab.html.Page",
          "items": [
            {
              "required": true,
              "type": "html",
              "content": "\u003Chead\u003E\r\n    \u003Cmeta charset=\"UTF-8\"\u003E\r\n    \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\r\n    \r\n    \u003Cstyle\u003E\r\n        body {\r\n            display: flex;\r\n            flex-direction: column;\r\n            align-items: center;\r\n            justify-content: center;\r\n            min-height: 100vh;\r\n            margin: 0;\r\n            font-family: Arial, sans-serif;\r\n        }\r\n\r\n        .instruction-text {\r\n            text-align: center;\r\n            font-size: 24px;\r\n            \u002F\u002Fmax-width: 90%;\r\n        }\r\n        .targetWord {\r\n            font-size: 64px;\r\n            text-align: center;\r\n            margin: 20px 0;\r\n        }\r\n\r\n        .area-container { \u002F* button*\u002F\r\n            width: 80%;\r\n            aspect-ratio: 4 \u002F 1;\r\n            border-radius: 8px;\r\n            background-color: #e0e0e0; \u002F* Rectangle's fill color *\u002F\r\n            display: flex;\r\n            align-items: center;\r\n            justify-content: center;\r\n            text-align: center;\r\n            margin: 0 auto;\r\n            color: black; \u002F* Text color inside the rectangle *\u002F\r\n            font-size: 24px;\r\n        }\r\n        \u002F\u002F.finish-button {\r\n         \u002F\u002F   position: absolute;\r\n          \u002F\u002F   bottom: 20px;\r\n          \u002F\u002F   right: 20px;\r\n          \u002F\u002F   padding: 10px 20px;\r\n          \u002F\u002F   background-color: #e0e0e0;\r\n          \u002F\u002F   border: none;\r\n          \u002F\u002F   border-radius: 8px;\r\n          \u002F\u002F   font-size: 18px;\r\n          \u002F\u002F   cursor: pointer;\r\n        \u002F\u002F }\r\n\r\n    \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody style=\"background-color: #ffffff; width: 100%; height: 100vh; margin: 0; padding: 0;\"\u003E\r\n\u003Cdiv style=\"width: 90%; margin: 0; position: absolute; top: 10%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n  \u003Cimg src=${ this.files[\"mikrophon.png\"] } alt=\"audio_aufnahme\" height = 50\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003Cdiv style=\" width: 90%; margin: 0; position: absolute; top: 45%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n        \u003Cdiv class=\"instruction-text\", style = \"text-align: center;\"\u003E\r\n          \u003Cspan id = \"instrText\"\u003EBitte nennen Sie alle Wörter, an die Sie sich erinnern.\u003C\u002Fspan\u003E\r\n    \u003C\u002Fdiv\u003E\r\n\r\n    \u003C\u002Fdiv\u003E\r\n      \u003Cdiv class=\"area-container\", id = \"fertig\", style = \"position: absolute; top: 75%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%)\" \u003E\r\n            Fertig\r\n        \u003C\u002Fdiv\u003E\r\n\r\n\u003C\u002Fbody\u003E",
              "name": ""
            }
          ],
          "scrollTop": true,
          "submitButtonText": "Continue →",
          "submitButtonPosition": "hidden",
          "files": {
            "mikrophon.png": "embedded\u002F16cbb94e16b7a85dd038131656be0825f486fb9b5bc9c797b6fd81e12c4cf225.png"
          },
          "responses": {
            "": ""
          },
          "parameters": {},
          "messageHandlers": {
            "before:prepare": async function anonymous(
) {
// Script for recording automatically
//
// This script must be added to the "before:prepare" stage.
//
// Note: Browsers block 'unexpected' audio recordings and playback. 
// The experiment must have some interaction before recording. 
//
// author: Tobias Busch (https://github.com/Teebusch)
// date: 2021-05-05


// I would like to change this so that the recording is only started, when someone clicks on the button maybe?
// ***** Configuration *******************
const codec = 'audio/ogg; codecs=opus';
//const stop_event = 'click #continue';

const timeout = 10000; // 10 sec
//const stop_event = 'click button#finish';


// ***************************************



let setupRecorder = function(stream) {
  console.log("Preparing recorder...");
  
  let mediaRecorder = new MediaRecorder(stream);
  let chunks = []; 
 
  mediaRecorder.onstart = function() {
    console.log("Recording started...");
  }

  mediaRecorder.onstop = async function() {
    console.log("Recording stopped...");

    blobToAudio = (blob) => {
      return new Promise((resolve, reject) => {
        let reader = new FileReader();

        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;

        reader.readAsDataURL(blob);
      })
    }

    const blob = new Blob(chunks, { 'type' : codec });
    let audio = await blobToAudio(blob);

    c.options.datastore.set('audio', audio);
    console.log("data stored...");

    c.end(reason = "timer");
  }

  mediaRecorder.ondataavailable = function(e) {
    chunks.push(e.data);
  }

  return(mediaRecorder);
}


let c = this;

// setup recorder as early as possible before run
let stream = await navigator.mediaDevices.getUserMedia({ audio: true });
 recorder = await setupRecorder(stream); // wihtout let to make it a global variable

//c.options.events[stop_event] = (e) => {
//    console.log(e);
//    if (recorder.state == 'recording') recorder.stop();
//  }

// when run starts set up recorder and timer for stop
c.waitFor('run').then(() => {
  recorder.start();
  setTimeout(() => {
    if (recorder.state == 'recording') recorder.stop();
  }, timeout);

  // if stop-event recorder,stp
});

//c.end(reason = stop_event);


},
            "run": function anonymous(
) {

var textIndex = 0;
var testChunkIndex = 0;
var instructions = document.getElementById("instrText");
var contButton = document.getElementById("fertig");


// function to create next stimulus
if (recallTextIndex == 1){
  instructions.innerText = 'Sind Sie wirklich fertig? \nDann können Sie erneut auf "Fertig" klicken.\n\nAnsonsten nennen Sie alle restlichen Wörter, an die Sie sich erinnern.';
  

};



// when click
contButton.addEventListener("click", () => {
  console.log(textIndex);
    
// WHYYY IS THIS NOT TRUE?!!!!
    if(recallTextIndex == 0){
      console.log("This is true.")
      recallTextIndex = 1;
      
    } else {
      console.log("That is true.")
      recallTimeOver = 1;
    }

  
console.log("recallTextIndex");
console.log(recallTextIndex);
console.log("recallTimeOver");
  console.log(recallTimeOver);
  recorder.stop();
  
});

}
          },
          "title": "MemoryRecall",
          "skip": "${recallTimeOver == 1} "
        },
        {
          "type": "lab.flow.Loop",
          "templateParameters": [
            {
              "parameterPlaceholder": "placeholder",
              "": ""
            }
          ],
          "sample": {
            "mode": "draw-replace",
            "n": "24"
          },
          "files": {},
          "responses": {
            "": "",
            "undefined": ""
          },
          "parameters": {},
          "messageHandlers": {},
          "title": "MemoryRecallChunks",
          "shuffleGroups": [],
          "template": {
            "type": "lab.html.Page",
            "items": [
              {
                "required": true,
                "type": "html",
                "content": "\u003Chead\u003E\r\n    \u003Cmeta charset=\"UTF-8\"\u003E\r\n    \u003Cmeta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"\u003E\r\n    \r\n    \u003Cstyle\u003E\r\n        body {\r\n            display: flex;\r\n            flex-direction: column;\r\n            align-items: center;\r\n            justify-content: center;\r\n            min-height: 100vh;\r\n            margin: 0;\r\n            font-family: Arial, sans-serif;\r\n        }\r\n\r\n        .instruction-text {\r\n            text-align: center;\r\n            font-size: 24px;\r\n            \u002F\u002Fmax-width: 90%;\r\n        }\r\n        .targetWord {\r\n            font-size: 64px;\r\n            text-align: center;\r\n            margin: 20px 0;\r\n        }\r\n\r\n        .area-container { \u002F* button*\u002F\r\n            width: 80%;\r\n            aspect-ratio: 4 \u002F 1;\r\n            border-radius: 8px;\r\n            background-color: #e0e0e0; \u002F* Rectangle's fill color *\u002F\r\n            display: flex;\r\n            align-items: center;\r\n            justify-content: center;\r\n            text-align: center;\r\n            margin: 0 auto;\r\n            color: black; \u002F* Text color inside the rectangle *\u002F\r\n            font-size: 24px;\r\n        }\r\n        \u002F\u002F.finish-button {\r\n         \u002F\u002F   position: absolute;\r\n          \u002F\u002F   bottom: 20px;\r\n          \u002F\u002F   right: 20px;\r\n          \u002F\u002F   padding: 10px 20px;\r\n          \u002F\u002F   background-color: #e0e0e0;\r\n          \u002F\u002F   border: none;\r\n          \u002F\u002F   border-radius: 8px;\r\n          \u002F\u002F   font-size: 18px;\r\n          \u002F\u002F   cursor: pointer;\r\n        \u002F\u002F }\r\n\r\n    \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody style=\"background-color: #ffffff; width: 100%; height: 100vh; margin: 0; padding: 0;\"\u003E\r\n\u003Cdiv style=\"width: 90%; margin: 0; position: absolute; top: 10%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n  \u003Cimg src=${ this.files[\"mikrophon.png\"] } alt=\"audio_aufnahme\" height = 50\u003E\r\n\u003C\u002Fdiv\u003E\r\n\u003Cdiv style=\" width: 90%; margin: 0; position: absolute; top: 45%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n        \u003Cdiv class=\"instruction-text\", style = \"text-align: center;\"\u003E\r\n          \u003Cspan id = \"instrText\"\u003EBitte nennen Sie alle Wörter, an die Sie sich erinnern.\u003C\u002Fspan\u003E\r\n    \u003C\u002Fdiv\u003E\r\n\r\n    \u003C\u002Fdiv\u003E\r\n      \u003Cdiv class=\"area-container\", id = \"fertig\", style = \"position: absolute; top: 75%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%)\" \u003E\r\n            Fertig\r\n        \u003C\u002Fdiv\u003E\r\n\r\n\u003C\u002Fbody\u003E",
                "name": ""
              }
            ],
            "scrollTop": true,
            "submitButtonText": "Continue →",
            "submitButtonPosition": "hidden",
            "files": {
              "mikrophon.png": "embedded\u002F16cbb94e16b7a85dd038131656be0825f486fb9b5bc9c797b6fd81e12c4cf225.png"
            },
            "responses": {
              "": ""
            },
            "parameters": {},
            "messageHandlers": {
              "before:prepare": async function anonymous(
) {
// Script for recording automatically
//
// This script must be added to the "before:prepare" stage.
//
// Note: Browsers block 'unexpected' audio recordings and playback. 
// The experiment must have some interaction before recording. 
//
// author: Tobias Busch (https://github.com/Teebusch)
// date: 2021-05-05


// I would like to change this so that the recording is only started, when someone clicks on the button maybe?
// ***** Configuration *******************
const codec = 'audio/ogg; codecs=opus';
//const stop_event = 'click #continue';

const timeout = 10000; // 10 sec
//const stop_event = 'click button#finish';


// ***************************************



let setupRecorder = function(stream) {
  console.log("Preparing recorder...");
  
  let mediaRecorder = new MediaRecorder(stream);
  let chunks = []; 
 
  mediaRecorder.onstart = function() {
    console.log("Recording started...");
  }

  mediaRecorder.onstop = async function() {
    console.log("Recording stopped...");

    blobToAudio = (blob) => {
      return new Promise((resolve, reject) => {
        let reader = new FileReader();

        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;

        reader.readAsDataURL(blob);
      })
    }

    const blob = new Blob(chunks, { 'type' : codec });
    let audio = await blobToAudio(blob);

    c.options.datastore.set('audio', audio);
    console.log("data stored...");

    c.end(reason = "timer");
  }

  mediaRecorder.ondataavailable = function(e) {
    chunks.push(e.data);
  }

  return(mediaRecorder);
}


let c = this;

// setup recorder as early as possible before run
let stream = await navigator.mediaDevices.getUserMedia({ audio: true });
 recorder = await setupRecorder(stream); // wihtout let to make it a global variable

//c.options.events[stop_event] = (e) => {
//    console.log(e);
//    if (recorder.state == 'recording') recorder.stop();
//  }

// when run starts set up recorder and timer for stop
c.waitFor('run').then(() => {
  recorder.start();
  setTimeout(() => {
    if (recorder.state == 'recording') recorder.stop();
  }, timeout);

  // if stop-event recorder,stp
});

//c.end(reason = stop_event);


},
              "run": function anonymous(
) {

var textIndex = 0;
var testChunkIndex = 0;
var instructions = document.getElementById("instrText");
var contButton = document.getElementById("fertig");


// function to create next stimulus
if (recallTextIndex == 1){
  instructions.innerText = 'Sind Sie wirklich fertig? \nDann können Sie erneut auf "Fertig" klicken.\n\nAnsonsten nennen Sie alle restlichen Wörter, an die Sie sich erinnern.';
  

};



// when click
contButton.addEventListener("click", () => {
  console.log(textIndex);
    
// WHYYY IS THIS NOT TRUE?!!!!
    if(recallTextIndex == 0){
      console.log("This is true.")
      recallTextIndex = 1;
      
    } else {
      console.log("That is true.")
      recallTimeOver = 1;
    }

  
console.log("recallTextIndex");
console.log(recallTextIndex);
console.log("recallTimeOver");
  console.log(recallTimeOver);
  recorder.stop();
  
});

}
            },
            "title": "MemoryRecall",
            "tardy": true,
            "skip": "${recallTimeOver == 1} "
          }
        }
      ]
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "required": true,
          "type": "html",
          "content": "\u003Chead\u003E\r\n  \u003Ctitle\u003ELadebalken\u003C\u002Ftitle\u003E\r\n  \u003Cstyle\u003E\r\n    body {\r\n      position: absolute;\r\n      top: 50%;\r\n      left: 50%;\r\n      transform: translate(-50%, -50%);\r\n      text-align: center;\r\n    }\r\n    #bild {\r\n      width: 500px;\r\n      height: 300px;\r\n      border: 1px solid #ccc;\r\n      margin: 0 auto;\r\n    }\r\n    #text {\r\n      margin-bottom: 20px;\r\n    }\r\n    #ladebalken {\r\n      width: 90vw;\r\n      height: 20px;\r\n      border: 1px solid #ccc;\r\n      background-color: #eee;\r\n      margin: 0 auto;\r\n      margin-top: 20px;\r\n    }\r\n    #ladebalken .fortschritt {\r\n      background-color: #666;\r\n      height: 20px;\r\n    }\r\n  \u003C\u002Fstyle\u003E\r\n\u003C\u002Fhead\u003E\r\n\u003Cbody\u003E\r\n  \u003Cdiv style = \"width: 100%; margin: 0; position: absolute; top: 50%; left: 50%; -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%); text-align: center;\"\u003E\r\n    \u003Ch1 id=\"text\"\"\u003EAudioaufnahme wird beendet...\u003C\u002Fh1\u003E\r\n    \u003Cimg src=${ this.files[\"mikrophon.png\"] } alt=\"audio_aufnahme\" height=\"200\" style=\"margin: 0 auto; display: block;\"\u003E\r\n    \u003Cdiv id=\"ladebalken\"\u003E\r\n      \u003Cdiv class=\"fortschritt\" style=\"width: 0%\"\u003E\u003C\u002Fdiv\u003E\r\n    \u003C\u002Fdiv\u003E\r\n  \u003C\u002Fdiv\u003E\r\n\u003C\u002Fbody\u003E",
          "name": ""
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "hidden",
      "files": {
        "mikrophon.png": "embedded\u002F16cbb94e16b7a85dd038131656be0825f486fb9b5bc9c797b6fd81e12c4cf225.png"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {
        "run": function anonymous(
) {
var ladebalken = document.getElementById("ladebalken");
var fortschritt = document.querySelector(".fortschritt");
var startzeit = new Date().getTime();
var endzeit = startzeit + 3000; // 3 Sekunden (1 Sekunde Wartezeit + 2 Sekunden Ladebalken)

function aktualisiereLadebalken() {
  var aktuelleZeit = new Date().getTime();
  var wartezeit = startzeit + 1000; // 1 Sekunde Wartezeit
  if (aktuelleZeit < wartezeit) {
    setTimeout(aktualisiereLadebalken, 16); // 16ms = 60fps
  } else {
    var fortschrittProzent = ((aktuelleZeit - wartezeit) / (endzeit - wartezeit)) * 100;
    fortschritt.style.width = fortschrittProzent + "%";
    if (aktuelleZeit < endzeit) {
      setTimeout(aktualisiereLadebalken, 16); // 16ms = 60fps
    } else {
      fortschritt.style.width = "100%";
    }
  }
}

aktualisiereLadebalken();
}
      },
      "title": "Stop Audio",
      "timeout": "3000"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": -25,
          "angle": 0,
          "width": 2,
          "height": 36.16,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 25,
          "top": -125,
          "angle": 0,
          "width": 428.71,
          "height": 78.11,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Bitte Warten Sie kurz.\nDie Daten werden übertragen.",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "image",
          "left": 10,
          "top": 100,
          "angle": 0,
          "width": 362.88,
          "height": 307.8,
          "stroke": null,
          "strokeWidth": 0,
          "fill": "black",
          "src": "${ this.files[\"covision_logo_short_black_blue_orange(1).png\"] }"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {
        "covision_logo_short_black_blue_orange(1).png": "embedded\u002Fc75489a57916f11757bcd1795400528b51d5f9858e64fbaefe640248c2ebd19b.png"
      },
      "responses": {
        "click": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Wait",
      "timeout": "0"
    }
  ]
})

// Let's go!
study.run()